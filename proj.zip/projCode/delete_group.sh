#!/bin/bash

read -p "Let me know the name of the group you want to delete: " group_name
sudo groupdel "$group_name"

echo "I've deleted group '$group_name'."
