#!/bin/bash

echo "Here is the list of users on our system!:"
getent passwd | cut -d: -f1
