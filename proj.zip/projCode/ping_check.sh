#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root!" >&2
    exit 1
fi

HOST=google.com
COUNT=5  # Number of pings to send
SUM=0

for i in $(seq 1 $COUNT); do
    if ping -c 1 -W 1 $HOST > /dev/null; then
        # Extract the latency from the ping output
        LATENCY=$(ping -c 1 -W 1 $HOST | grep -oP 'time=\K[\d.]+')
        echo "Ping #$i: $LATENCY ms"
        SUM=$(echo "$SUM + $LATENCY" | bc)
    else
        echo "Ping #$i: timeout"
    fi
done

AVG=$(echo "scale=2; $SUM / $COUNT" | bc)
echo "Average latency: $AVG ms"
