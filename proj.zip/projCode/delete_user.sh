#!/bin/bash

read -p "Which user would you like me to delete?: " user_name
sudo userdel -f "$user_name"

echo "I've deleted '$user_name'."
