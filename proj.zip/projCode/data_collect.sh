#!/bin/bash

OUTPUT_FILE="system_metrics.csv"

echo "timestamp,cpu_usage,memory_usage,disk_usage,load_avg_1m,load_avg_5m,load_avg_15m,swap_usage" > $OUTPUT_FILE

while true; do
  timestamp=$(date +%s)
  cpu_usage=$(top -b -n1 | grep "Cpu(s)" | awk '{print $2 + $4}')
  memory_usage=$(free -m | awk 'NR==2{printf "%.2f", $3*100/$2}')
  disk_usage=$(df --output=pcent / | tail -1 | tr -dc '0-9')
  load_avgs=$(uptime | awk -F'[a-z]:' '{ print $2 }' | awk -F',' '{print $1 "," $2 "," $3}')
  swap_usage=$(free -m | awk 'NR==3{printf "%.2f", $3*100/$2}')

  echo "$timestamp,$cpu_usage,$memory_usage,$disk_usage,$load_avgs,$swap_usage" >> $OUTPUT_FILE

  sleep 10
done
