import pandas as pd
import plotly.graph_objs as go
import plotly.subplots as sp

def main():

	data = pd.read_csv("system_metrics.csv")

	data['timestamp'] = pd.to_datetime(data['timestamp'], unit='s')

	fig = sp.make_subplots(rows=3, cols=2, subplot_titles=('CPU Usage', 'Memory Usage', 'Disk Usage', 'System Load Averages', 'Swap Usage'))

	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['cpu_usage'], mode='lines', name='CPU Usage (%)'), row=1, col=1)

	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['memory_usage'], mode='lines', name='Memory Usage (%)'), row=1, col=2)
	#fig.add_trace(go.Scatter(x=data['timestamp'], y=data['memory_usage'], mode='lines', fill='tozeroy', name='Memory Usage (%)'), row=1, col=2)


	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['disk_usage'], mode='lines', name='Disk Usage (%)'), row=2, col=1)

	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['load_avg_1m'], mode='lines', name='1-min'), row=2, col=2)

	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['load_avg_5m'], mode='lines', name='5-min Load Average', visible='legendonly'), row=2, col=2)
	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['load_avg_15m'], mode='lines', name='15-min Load Average', visible='legendonly'), row=2, col=2)

	fig.add_trace(go.Scatter(x=data['timestamp'], y=data['swap_usage'], mode='lines', name='Swap Usage (%)'), row=3, col=1)

	fig.update_layout(title='System Performance Metrics', showlegend=True)
	fig.update_yaxes(title_text='%', row=1, col=1)
	fig.update_yaxes(title_text='%', row=1, col=2)
	fig.update_yaxes(title_text='%', row=2, col=1)
	fig.update_yaxes(title_text='%', row=3, col=1)

	fig.show()