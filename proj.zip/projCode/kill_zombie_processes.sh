#!/bin/bash

# Get the list of zombie processes
zombies=$(ps aux | awk '{if ($8 == "Z") print $2}')

# Check if there are any zombie processes
if [[ -z "$zombies" ]]; then
    echo "No zombie processes found."
    exit 0
fi

# Kill the zombie processes
echo "Killing zombie processes: $zombies"
for pid in $zombies; do
    kill -9 "$pid"
done

echo "All zombie processes killed."

