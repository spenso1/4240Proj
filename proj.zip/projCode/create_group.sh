#!/bin/bash


read -p "Enter the name of the group you want to create: " group_name
read -p "Enter the directory path where you want to set permissions (path/to/directory): " directory_path


sudo groupadd "$group_name"


sudo setfacl -d -m group:"$group_name":rwx "$directory_path"


sudo setfacl -m group:"$group_name":rwx "$directory_path"

echo "Group '$group_name' created and permissions set for '$directory_path'."
