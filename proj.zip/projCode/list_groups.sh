#!/bin/bash

echo "Here are the groups on our system:"
getent group | cut -d: -f1
