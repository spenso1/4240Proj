#!/bin/bash


if [ "$(id -u)" -ne 0 ]; then
    echo "I need root privileges!" >&2
    exit 1
fi


read -p "Enter the username for the new user: " username

if id "$username" &>/dev/null; then
    echo "Heads up! User '$username' already exists. Please choose a different username." >&2
    exit 1
fi


useradd -m -s /bin/bash "$username"


echo "Enter the password for the new user:"
passwd "$username"

echo "I've created '$username' successfully."
