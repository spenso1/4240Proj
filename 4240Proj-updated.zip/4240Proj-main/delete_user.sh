#!/bin/bash

if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root!" >&2
    exit 1
fi

# Prompt the user for the username to be deleted
read -p "Enter the username to be deleted: " username

# Check if the user exists
if id "$username" &>/dev/null; then
    # Delete the user and their home directory
    userdel -r "$username"
    echo "User $username and their home directory have been deleted."
else
    echo "User $username does not exist."
fi
